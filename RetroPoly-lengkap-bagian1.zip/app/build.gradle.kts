plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ZeroTier tertanam bersifat OPSIONAL: hanya ikut bila scripts/setup_zerotier_core.sh berhasil (dan tidak dimatikan dengan -PnoZt=true).
// Tanpa itu, aplikasi tetap dibuild dan layar ZeroTier menampilkan bahwa mesinnya tidak ikut.
val ztReady = !project.hasProperty("noZt") &&
    file("zt-sdk/java/com/zerotier/sdk/Node.java").exists() &&
    file("src/main/jniLibs/arm64-v8a/libZeroTierOneJNI.so").exists()

android {
    namespace = "com.retropoly.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.retropoly.app"
        minSdk = 28            // Android 9 (syarat M64Plus FZ)
        targetSdk = 34
        versionCode = 29
        versionName = "1.4"

        // Satu APK saja, hanya arm64-v8a (HP 64-bit). HP 32-bit lama (armeabi-v7a) tidak lagi didukung.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    sourceSets {
        getByName("main") {
            // ZtEngine memakai SDK lewat refleksi, jadi aplikasi selalu bisa dikompilasi; SDK + .so hanya ikut bila siap.
            if (ztReady) java.srcDir("zt-sdk/java")
        }
    }

    // Tanda tangan TETAP untuk semua build (debug & release), supaya APK baru bisa menimpa/update APK lama.
    // Tanpa ini, tiap build di GitHub Actions memakai debug keystore acak -> tanda tangan berbeda -> update ditolak.
    // JANGAN ganti/hapus emulator-fixed.jks: bila berubah, APK harus di-uninstall dulu sekali.
    signingConfigs {
        create("fixed") {
            storeFile = file("emulator-fixed.jks")
            storePassword = "emulator123"
            keyAlias = "emulator"
            keyPassword = "emulator123"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("fixed") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true   // dibutuhkan modul M64Plus FZ
    }
    // Pustaka AndroidX terbaru (dari M64Plus FZ) memakai metadata Kotlin yang lebih baru dari plugin Kotlin proyek ini
    kotlinOptions { jvmTarget = "17"; freeCompilerArgs += "-Xskip-metadata-version-check" }

    // Core libretro dimuat lewat path, jadi .so harus diekstrak ke nativeLibraryDir
    packaging {
        jniLibs { useLegacyPackaging = true }
        // JNA (jna + jna-platform, dibawa M64Plus FZ) sama-sama memuat file lisensi ini -> "2 files found with path META-INF/AL2.0".
        // Berkas lisensi tidak dibutuhkan saat berjalan, jadi cukup dibuang.
        resources {
            excludes += setOf(
                "META-INF/AL2.0", "META-INF/LGPL2.1",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES"
            )
        }
    }
}


dependencies {
    // M64Plus FZ (Nintendo 64) tertanam: library + plugin native di folder m64plus/ (lihat settings.gradle.kts)
    implementation(project(":m64plus-app"))
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Baca arsip .7z dan .rar (Java murni; .zip sudah bawaan Java)
    implementation("org.apache.commons:commons-compress:1.21")
    implementation("org.tukaani:xz:1.9")
    implementation("com.github.junrar:junrar:7.5.5")

    // Terjemahan dialog: OCR + penerjemah on-device (ML Kit). Cek versi terbaru bila gagal resolve.
    implementation("com.google.mlkit:text-recognition:16.0.1")            // Latin
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")
}
