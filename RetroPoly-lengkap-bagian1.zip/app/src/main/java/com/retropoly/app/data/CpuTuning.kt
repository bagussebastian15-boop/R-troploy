package com.retropoly.app.data


/**
 * Kecepatan CPU emulasi untuk SNES dan Genesis (mengurangi slowdown/lag bawaan game yang berat).
 * 100% = perilaku asli (tidak ada yang diubah); bawaan aplikasi 300%. Di atas 100% lebih lancar tapi lebih berat bagi HP,
 * dan sebagian kecil game bisa bermasalah.
 */
object CpuTuning {
    /** Bawaan kecepatan CPU SNES dan Genesis: 300%. */
    const val DEFAULT_SNES_GENESIS = 300

    val SNES_CHOICES = listOf(100, 150, 200, 300, 400)
    val GENESIS_CHOICES = listOf(100, 125, 150, 175, 200, 250, 300, 400)

    fun snesLabel(p: Int) = when {
        p <= 100 -> "100% (asli)"
        p < 200 -> "$p% (kompatibel)"
        else -> "$p% (maksimal)"
    }
}
