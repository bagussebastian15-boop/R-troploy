package com.retropoly.app.data


/** Pengaturan kecepatan CPU untuk game arcade (MAME dan FBNeo): daftar core dan pilihan di menu. */
object ArcadeTuning {

    /** Core arcade yang dipakai. */
    val CORES = Console.values().filter { it.isArcade }

    /** Kecepatan CPU bawaan (persen) untuk semua core arcade. */
    const val DEFAULT_CPU = 200

    /** Pilihan kecepatan CPU untuk menu (berlaku untuk semua core arcade yang punya opsinya). */
    val CPU_CHOICES = listOf(100, 110, 120, 130, 150, 175, 200, 250, 300)
}
