package com.retropoly.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Latar "gambar hidup" bergaya Aero: pita cahaya bergelombang, kilau meluncur di sepanjang pita,
 * sorotan cahaya vertikal yang berdenyut, sapuan cahaya, butiran cahaya, dan zoom pelan.
 * Semua gerak dihitung dari waktu (bukan hitungan frame) dan memakai sprite kecil tanpa blur,
 * jadi mulus di layar 60/90/120 Hz. Berhenti otomatis saat tidak terlihat.
 */
class AeroBackgroundView(context: Context, resId: Int) : View(context) {

    private val bmp: Bitmap = BitmapFactory.decodeResource(
        resources, resId, BitmapFactory.Options().apply { inScaled = false }
    )
    private val IW = 1920f
    private val IH = 1200f

    private val basePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val spritePaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = add }
    private val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = add; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    // mesh gelombang
    private val mw = 40
    private val mh = 28
    private val verts = FloatArray((mw + 1) * (mh + 1) * 2)

    // jalur pita (koordinat gambar 1920x1200)
    private class Ribbon(val rgb: Int, val pts: FloatArray, val sprite: Bitmap)
    private val ribbons: List<Ribbon>
    private val dustSprite: Bitmap

    private class Glint(val ribbon: Int, val speed: Float, val offset: Float, val size: Float)
    private class Dust(val x: Float, val y: Float, val r: Float, val vy: Float, val p: Float, val a: Float)
    private val glints = ArrayList<Glint>()
    private val dust = ArrayList<Dust>()

    // gradien sorotan vertikal & sapuan dibuat sekali (diskalakan lewat canvas)
    private val beamStops = floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
    private val beamColors = intArrayOf(0x00BEE1FF, 0x66BEE1FF, 0xFFBEE1FF.toInt(), 0x66BEE1FF, 0x00BEE1FF)
    private val beamShader = LinearGradient(-1f, 0f, 1f, 0f, beamColors, beamStops, Shader.TileMode.CLAMP)
    private val sweepShader = LinearGradient(
        -1f, 0f, 1f, 0f, intArrayOf(0x00AAE6FF, 0xFFAAE6FF.toInt(), 0x00AAE6FF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )

    private val path = Path()
    private val dst = RectF()
    private val t0 = SystemClock.uptimeMillis()
    private var running = false
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    init {
        fun cr(p0: Float, p1: Float, p2: Float, p3: Float, t: Float): Float {
            val t2 = t * t; val t3 = t2 * t
            return 0.5f * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
        }
        fun sample(raw: FloatArray): FloatArray {
            val n = raw.size / 2
            fun px(i: Int) = raw[i.coerceIn(0, n - 1) * 2]
            fun py(i: Int) = raw[i.coerceIn(0, n - 1) * 2 + 1]
            val out = ArrayList<Float>()
            for (i in 0 until n - 1) for (k in 0 until 24) {
                val t = k / 24f
                out += cr(px(i - 1), px(i), px(i + 1), px(i + 2), t)
                out += cr(py(i - 1), py(i), py(i + 1), py(i + 2), t)
            }
            out += px(n - 1); out += py(n - 1)
            return out.toFloatArray()
        }
        fun sprite(rgb: Int): Bitmap {
            val s = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val r = rgb and 0xFFFFFF
            p.shader = RadialGradient(
                32f, 32f, 32f,
                intArrayOf(0xFFFFFFFF.toInt(), (0x8C shl 24) or r, r),
                floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP
            )
            Canvas(s).drawCircle(32f, 32f, 32f, p)
            return s
        }
        val defs = listOf(
            0x96E6FF to floatArrayOf(600f,1150f, 900f,1010f, 1150f,900f, 1400f,760f, 1600f,630f, 1780f,480f, 1920f,330f),
            0x82C8FF to floatArrayOf(700f,1120f, 1000f,990f, 1280f,860f, 1500f,720f, 1720f,570f, 1920f,380f),
            0x96FFAA to floatArrayOf(1820f,0f, 1760f,150f, 1680f,300f, 1590f,430f, 1480f,540f, 1350f,680f),
            0x8CFFAA to floatArrayOf(930f,1200f, 1150f,1110f, 1400f,980f, 1650f,820f, 1920f,520f)
        )
        ribbons = defs.map { (rgb, raw) -> Ribbon(rgb, sample(raw), sprite(rgb)) }
        dustSprite = sprite(0xC8EBFF)
        val rnd = Random(11)
        repeat(14) { glints += Glint(it % 4, 0.10f + rnd.nextFloat() * 0.16f, rnd.nextFloat() * 1.25f, 0.7f + rnd.nextFloat() * 0.7f) }
        repeat(36) {
            dust += Dust(rnd.nextFloat() * IW, rnd.nextFloat() * 1200f, 5f + rnd.nextFloat() * 11f,
                6f + rnd.nextFloat() * 20f, rnd.nextFloat() * 6.28f, 0.15f + rnd.nextFloat() * 0.30f)
        }
    }

    fun start() {
        if (running) return
        running = true
        Choreographer.getInstance().postFrameCallback(frame)
    }

    fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (visibility == VISIBLE) start() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) start() else stop()
    }

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t)
    }

    override fun onDraw(canvas: Canvas) {
        val vw = width.toFloat(); val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val tau = 2f * PI.toFloat()

        // zoom pelan + geser tipis; skala minimum 1.06 supaya tepi tidak terbuka saat mesh bergeser
        val z = 1.06f + 0.04f * (0.5f - 0.5f * cos(t * tau / 40f))
        val cover = max(vw / IW, vh / IH) * z
        val dw = IW * cover; val dh = IH * cover
        val dl = (vw - dw) / 2f + sin(t * tau / 53f) * vw * 0.01f
        val dt = (vh - dh) * 0.55f

        // ---- gambar dasar dengan mesh bergelombang (makin kuat ke arah kanan, tempat pita berada)
        val sx = dw / mw; val sy = dh / mh
        var k = 0
        for (j in 0..mh) {
            val fy = j.toFloat() / mh
            for (i in 0..mw) {
                val fx = i.toFloat() / mw
                val m = smooth(0.25f, 0.85f, fx)
                val ox = m * dw * (0.006f * sin(t * 0.9f + fy * 5f + fx * 2f) + 0.003f * sin(t * 1.7f + fy * 11f))
                val oy = m * dh * (0.005f * cos(t * 0.7f + fx * 4f - fy * 3f) + 0.002f * cos(t * 1.3f + fx * 9f))
                verts[k] = dl + i * sx + ox; verts[k + 1] = dt + j * sy + oy
                k += 2
            }
        }
        canvas.drawBitmapMesh(bmp, mw, mh, verts, 0, null, 0, basePaint)

        val kx = dw / IW; val ky = dh / IH
        fun mx(x: Float) = dl + x * kx
        fun my(y: Float) = dt + y * ky

        // ---- pita "bernapas": goresan tipis berdenyut di atas pita asli
        for ((idx, r) in ribbons.withIndex()) {
            path.rewind()
            var q = 0
            while (q < r.pts.size) {
                val px = mx(r.pts[q]); val py = my(r.pts[q + 1])
                if (q == 0) path.moveTo(px, py) else path.lineTo(px, py)
                q += 2
            }
            val a = 0.10f + 0.09f * sin(t * 1.2f + idx * 1.3f)
            val c = r.rgb and 0xFFFFFF
            strokePaint.strokeWidth = (if (idx == 0) 16f else 10f) * kx
            strokePaint.color = ((a * 0.45f * 255).toInt() shl 24) or c
            canvas.drawPath(path, strokePaint)
            strokePaint.strokeWidth = (if (idx == 0) 6f else 3.5f) * kx
            strokePaint.color = ((a * 255).toInt() shl 24) or c
            canvas.drawPath(path, strokePaint)
        }

        // ---- sorotan cahaya vertikal berdenyut (dibuat dari beberapa pita tipis yang makin pudar ke bawah)
        val beams = arrayOf(
            floatArrayOf(0.50f, 0.07f, 0.0f, 0.9f),
            floatArrayOf(0.60f, 0.04f, 2.1f, 1.2f),
            floatArrayOf(0.40f, 0.05f, 4.3f, 0.7f)
        )
        val bands = 6
        for (b in beams) {
            val pulse = 0.5f + 0.5f * sin(t * b[3] + b[2])
            val hw = b[1] * dw * 1.8f
            val cx0 = dl + b[0] * dw + 0.02f * dw * sin(t * 0.4f + b[2])
            for (j in 0 until bands) {
                val y0 = dt + dh * 0.9f * j / bands; val y1 = dt + dh * 0.9f * (j + 1) / bands
                val mid = (j + 0.5f) / bands
                val fade = 1f - mid * 0.85f * 0.9f
                beamPaint.shader = beamShader
                beamPaint.alpha = ((0.04f + 0.13f * pulse) * 1.6f * fade * 255).toInt().coerceIn(0, 255)
                canvas.save()
                canvas.translate(cx0 + 0.05f * dh * mid, 0f)   // miring tipis
                canvas.scale(hw, 1f)
                canvas.drawRect(-1f, y0, 1f, y1 + 1f, beamPaint)
                canvas.restore()
            }
        }

        // ---- sapuan cahaya melintang tiap 9 detik
        val cyc = (t / 9f) % 1f
        val swx = (cyc * 1.6f - 0.3f) * vw
        sweepPaint.shader = sweepShader
        sweepPaint.alpha = 38
        canvas.save(); canvas.translate(swx, 0f); canvas.scale(0.12f * vw, 1f)
        canvas.drawRect(-1f, 0f, 1f, vh, sweepPaint); canvas.restore()

        // ---- kilau yang meluncur di sepanjang pita
        for (g in glints) {
            val u0 = ((t * g.speed + g.offset) % 1.25f) - 0.1f
            val r = ribbons[g.ribbon]
            val n = r.pts.size / 2 - 1
            for (s in 0 until 16) {
                val u = u0 - s * 0.006f
                if (u < 0f || u > 1f) continue
                val f = u * n; val i = f.toInt().coerceAtMost(n - 1); val fr = f - i
                val px = mx(r.pts[i * 2] + (r.pts[i * 2 + 2] - r.pts[i * 2]) * fr)
                val py = my(r.pts[i * 2 + 1] + (r.pts[i * 2 + 3] - r.pts[i * 2 + 1]) * fr)
                val rad = (5.5f - s * 0.2f) * g.size * kx * 2.2f
                spritePaint.alpha = ((1f - s / 16f) * 0.9f * 255).toInt()
                dst.set(px - rad, py - rad, px + rad, py + rad)
                canvas.drawBitmap(r.sprite, null, dst, spritePaint)
            }
        }

        // ---- butiran cahaya naik pelan
        for (d in dust) {
            val yy = (((d.y - t * d.vy) % 1210f) + 1210f) % 1210f - 5f
            val xx = d.x + sin(t * 0.7f + d.p) * 15f
            val rad = d.r * kx * 2f
            spritePaint.alpha = (d.a * (0.5f + 0.5f * sin(t * 1.5f + d.p)) * 255).toInt().coerceIn(0, 255)
            val px = mx(xx); val py = my(yy)
            dst.set(px - rad, py - rad, px + rad, py + rad)
            canvas.drawBitmap(dustSprite, null, dst, spritePaint)
        }
    }
}
