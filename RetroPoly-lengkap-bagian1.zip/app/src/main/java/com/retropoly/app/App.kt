package com.retropoly.app

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.retropoly.app.ui.UiSound

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        UiSound.init(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) { UiSound.hook(activity.window) }
            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
