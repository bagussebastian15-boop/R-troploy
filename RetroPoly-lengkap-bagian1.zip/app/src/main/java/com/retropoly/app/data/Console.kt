package com.retropoly.app.data

/** Sistem yang didukung. `core` = nama file library core di nativeLibraryDir. */
enum class Console(val label: String, val core: String, val extensions: Set<String>) {
    GBA("Game Boy Advance", "libmgba_libretro_android.so", setOf("gba")),
    SNES("Super Nintendo (SNES)", "libsnes9x_libretro_android.so", setOf("sfc", "smc", "fig", "swc")),
    GENESIS("Sega Genesis / Mega Drive", "libgenesis_plus_gx_libretro_android.so", setOf("md", "gen", "smd", "bin")),
    /** Nintendo 64: dijalankan oleh M64Plus FZ yang tertanam (modul m64plus-app, lihat LibraryActivity.launchM64Plus). Entri ini hanya kategori library untuk .z64/.n64/.v64. */
    N64("Nintendo 64", "", setOf("z64", "n64", "v64")),
    /** Core arcade bawaan: semua file .zip arcade masuk library dengan core ini. */
    ARCADE_MAME("Arcade (MAME 2010)", "libmame2010_libretro_android.so", setOf("zip")),
    /**
     * Pilihan core kedua untuk game arcade yang sama (muncul saat tekan lama game arcade di library).
     * Tidak punya ekstensi/folder ROM sendiri: memakai file zip di folder arcade MAME, jadi set ROM-nya harus cocok dengan FBNeo.
     */
    ARCADE_FBNEO("Arcade (FBNeo)", "libfbneo_libretro_android.so", emptySet()),
    /** Core arcade tambahan (pilihan tekan lama): memakai zip yang sama di folder arcade, set ROM-nya mengikuti versi core masing-masing. */
    ARCADE_FBA2012("Arcade (FB Alpha 2012)", "libfbalpha2012_libretro_android.so", emptySet()),
    ARCADE_MAME2000("Arcade (MAME 2000, set 0.37b5)", "libmame2000_libretro_android.so", emptySet()),
    ARCADE_MAME2003("Arcade (MAME 2003, set 0.78)", "libmame2003_libretro_android.so", emptySet()),
    ARCADE_MAME2003P("Arcade (MAME 2003-Plus, set 0.78+)", "libmame2003_plus_libretro_android.so", emptySet());

    val isArcade: Boolean get() = name.startsWith("ARCADE_")

    val supportsNetplay: Boolean get() = false   // multiplayer rollback (LibretroDroid) sudah dihapus

    /** Dijalankan M64Plus FZ (activity sendiri), bukan lewat EmulatorActivity/libretro. */
    val isExternal: Boolean get() = this == N64

    companion object {
        /** .7z dan .rar ikut dianggap "arsip" yang awalnya masuk ke folder arcade, lalu isinya dibaca dan dipilah ke konsol yang tepat. */
        fun fromExtension(ext: String): Console? =
            values().firstOrNull { ext in it.extensions } ?: if (ext == "7z" || ext == "rar") ARCADE_MAME else null
    }
}
