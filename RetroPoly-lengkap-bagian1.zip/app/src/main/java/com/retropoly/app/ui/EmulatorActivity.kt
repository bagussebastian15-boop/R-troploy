package com.retropoly.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Pemutar libretro (LibretroDroid) sudah dihapus dari proyek ini, jadi activity ini hanya menutup diri.
 * Konstanta EXTRA_* tetap ada karena masih dirujuk LobbyActivity dan LibraryActivity.
 * Satu-satunya konsol yang berjalan: Nintendo 64 (M64Plus FZ tertanam).
 */
class EmulatorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        const val EXTRA_CONSOLE = "console"
        const val EXTRA_NP_MODE = "np_mode"
        const val EXTRA_NP_IP = "np_ip"
        const val EXTRA_NP_PORT = "np_port"
        const val EXTRA_NP_DELAY = "np_delay"
        const val EXTRA_NP_ROOM = "np_room"
        const val EXTRA_NP_VPN = "np_vpn"
        const val EXTRA_NP_INVITE = "np_invite"
        const val EXTRA_NP_PUBLIC_IP = "np_public_ip"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Toast.makeText(this, "Konsol ini belum punya emulator (pemutar libretro sudah dihapus).", Toast.LENGTH_LONG).show()
        finish()
    }
}
