package com.retropoly.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.preference.PreferenceManager
import paulscode.android.mupen64plusae.ActivityHelper
import paulscode.android.mupen64plusae.cheat.CheatUtils
import paulscode.android.mupen64plusae.persistent.AppData
import paulscode.android.mupen64plusae.persistent.ConfigFile
import paulscode.android.mupen64plusae.persistent.GlobalPrefs
import paulscode.android.mupen64plusae.task.ExtractAssetsOrCleanupTask
import paulscode.android.mupen64plusae.util.FileUtil
import paulscode.android.mupen64plusae.util.Notifier
import paulscode.android.mupen64plusae.util.RomDatabase
import paulscode.android.mupen64plusae.util.RomHeader
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import paulscode.android.mupen64plusae.R as EngineR

/**
 * Pintu masuk ke ENGINE N64 (Mupen64Plus) tanpa tampilan bawaannya.
 *
 * Dulu R€troPoly membuka SplashActivity milik M64Plus FZ -> galeri game M64Plus FZ -> baru game jalan.
 * Sekarang R€troPoly menyiapkan engine sendiri (data bawaan engine, info ROM) lalu langsung membuka layar emulasi.
 * Splash, galeri, dan layar pengaturan bawaan M64Plus FZ tidak pernah ditampilkan.
 */
class EngineLauncherActivity : AppCompatActivity(), ExtractAssetsOrCleanupTask.ExtractAssetsListener {

    companion object {
        const val EXTRA_ROM = "rom"
        private const val ASSET_DIR = "mupen64plus_data"   // folder data engine di dalam APK
    }

    private lateinit var status: TextView
    private lateinit var appData: AppData
    private lateinit var prefs: GlobalPrefs
    private var rom: File? = null
    private var launched = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            text = "Menyiapkan game…"
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(LinearLayout(this@EngineLauncherActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
                addView(ProgressBar(this@EngineLauncherActivity))
                addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = (12 * d).toInt() })
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        })

        val path = intent.getStringExtra(EXTRA_ROM)
        val f = if (path != null) File(path) else null
        if (f == null || !f.exists()) { status.text = "File ROM tidak ditemukan."; return }
        rom = f

        // Engine membutuhkan pengaturan dasar terisi (nilai bawaan), sama seperti saat M64Plus FZ pertama dibuka.
        appData = AppData(this)
        PreferenceManager.setDefaultValues(this, EngineR.xml.preferences_audio, false)
        PreferenceManager.setDefaultValues(this, EngineR.xml.preferences_data, false)
        PreferenceManager.setDefaultValues(this, EngineR.xml.preferences_display, false)
        PreferenceManager.setDefaultValues(this, EngineR.xml.preferences_input, false)
        PreferenceManager.setDefaultValues(this, EngineR.xml.preferences_library, false)
        PreferenceManager.setDefaultValues(this, EngineR.xml.preferences_touchscreen, false)
        prefs = GlobalPrefs(this, appData)
        FileUtil.makeDirs(prefs.touchscreenCustomSkinsDir)
        Notifier.initialize(this)

        // Notifikasi dibutuhkan layanan emulasi (Android 13+); tidak menghalangi permainan bila ditolak.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 177)

        val needExtract = appData.getAssetCheckNeeded() || appData.getAppVersion() != appData.appVersionCode ||
            !ExtractAssetsOrCleanupTask.areAllAssetsValid(
                PreferenceManager.getDefaultSharedPreferences(this), ASSET_DIR, appData.coreSharedDataDir
            )
        if (needExtract) {
            appData.putAppVersion(appData.appVersionCode)
            status.text = "Menyiapkan engine N64 (sekali saja)…"
            ExtractAssetsOrCleanupTask(this, assets, appData, prefs, ASSET_DIR, appData.coreSharedDataDir, this).doInBackground()
        } else {
            prepareAndStart()
        }
    }

    override fun onExtractAssetsProgress(nextFileToExtract: String?, currentAsset: Int, totalAssets: Int) {
        runOnUiThread {
            val pct = if (totalAssets > 0) 100f * currentAsset / totalAssets else 0f
            status.text = "Menyiapkan engine N64… ${pct.toInt()}%"
        }
    }

    override fun onExtractAssetsFinished(failures: MutableList<ExtractAssetsOrCleanupTask.Failure>?) {
        runOnUiThread {
            if (!failures.isNullOrEmpty()) {
                appData.putAssetCheckNeeded(true)
                status.text = "Data engine gagal disiapkan:\n" + failures.joinToString("\n") { it.toString() }
            } else {
                appData.putAssetCheckNeeded(false)
                prepareAndStart()
            }
        }
    }

    /** Hitung info ROM (MD5, CRC, nama, kode negara) di thread lain, lalu langsung buka layar emulasi. */
    private fun prepareAndStart() {
        if (launched) return
        launched = true
        val file = rom ?: return
        status.text = "Membaca ROM…"
        Thread {
            try {
                CheatUtils.mergeCheatFiles(appData.mupencheat_default, prefs.customCheats_txt, appData.mupencheat_txt)
                val db = RomDatabase.getInstance()
                if (!db.hasDatabaseFile()) db.setDatabaseFile(appData.mupen64plus_ini)

                val header = RomHeader(file)
                val md5 = BufferedInputStream(FileInputStream(file)).use { FileUtil.computeMd5(it) }
                val detail = db.lookupByMd5WithFallback(md5, file.name, header.crc, header.countryCode)
                val artPath = prefs.coverArtDir + "/" + detail.artName
                val goodName = detail.goodName ?: ""
                val display = when {
                    !detail.baseName.isNullOrEmpty() -> detail.baseName
                    goodName.isNotEmpty() -> goodName
                    else -> file.nameWithoutExtension
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.files", file).toString()

                // Catat di cache info ROM milik engine (dipakai pengaturan per-game), seperti yang dulu dikerjakan galerinya.
                val cfg = ConfigFile(prefs.romInfoCacheCfg)
                if (cfg.get(md5) == null) {
                    cfg.put(md5, "goodName", goodName)
                    if (!detail.baseName.isNullOrEmpty()) cfg.put(md5, "baseName", detail.baseName)
                    cfg.put(md5, "romPathUri", uri)
                    cfg.put(md5, "zipPathUri", "")
                    cfg.put(md5, "artPath", artPath)
                    cfg.put(md5, "crc", header.crc)
                    cfg.put(md5, "headerName", header.name)
                    cfg.put(md5, "countryCode", header.countryCode.value.toString())
                }
                cfg.put(md5, "lastPlayed", (System.currentTimeMillis() / 1000).toInt().toString())
                cfg.save()

                runOnUiThread {
                    ActivityHelper.startGameActivity(
                        this, uri, "", md5, header.crc, header.name, header.countryCode.value,
                        artPath, goodName, display, true
                    )
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal membaca ROM: ${e.message}" }
            }
        }.start()
    }
}
