package com.retropoly.app.ui

/** Multiplayer rollback (LibretroDroid) sudah dihapus; hanya port bawaan lobby yang tersisa. */
object NetplayUi {
    const val PORT = 7755
}
