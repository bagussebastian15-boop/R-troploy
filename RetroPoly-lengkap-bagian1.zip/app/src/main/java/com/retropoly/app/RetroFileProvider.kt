package com.retropoly.app

import androidx.core.content.FileProvider

/**
 * FileProvider milik R€troPoly (authority "<paket>.files"). Dibuat sebagai subkelas sendiri supaya tidak bentrok
 * dengan FileProvider bawaan modul M64Plus FZ (authority "<paket>.filesprovider") saat manifest digabung.
 */
class RetroFileProvider : FileProvider()
