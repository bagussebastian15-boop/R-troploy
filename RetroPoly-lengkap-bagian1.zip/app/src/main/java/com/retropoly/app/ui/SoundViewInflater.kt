package com.retropoly.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatViewInflater
import androidx.appcompat.widget.AlertDialogLayout

/**
 * Dipasang lewat tema (viewInflaterClass). Akar tampilan setiap AlertDialog diganti [SoundDialogLayout]
 * supaya ketukan di dalam dialog (tombol, pilihan di daftar, kotak centang) bisa berbunyi.
 */
class SoundViewInflater : AppCompatViewInflater() {
    override fun createView(context: Context, name: String, attrs: AttributeSet): View? =
        if (name == "androidx.appcompat.widget.AlertDialogLayout") SoundDialogLayout(context, attrs) else null
}

@SuppressLint("RestrictedApi")
class SoundDialogLayout(context: Context, attrs: AttributeSet?) : AlertDialogLayout(context, attrs) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        UiSound.dialogTouch(this, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        UiSound.keyPressed(this, event, true)
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        UiSound.motionPressed(event)
        return super.dispatchGenericMotionEvent(event)
    }
}
