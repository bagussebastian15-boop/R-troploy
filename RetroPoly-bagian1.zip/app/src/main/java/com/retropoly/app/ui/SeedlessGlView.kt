package com.retropoly.app.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.SystemClock
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.HapticFeedbackConstants
import android.view.ViewConfiguration
import com.retropoly.app.R
import com.retropoly.app.data.SeedlessSettings
import com.seedlessds.app.SeedlessBridge
import com.seedlessds.app.filesystem.PathCache
import com.seedlessds.core.SeedlessCore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLContext
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.egl.EGLSurface

/**
 * Penyaji dua layar NDS untuk core NDS. Versi ringkas dari DsGlView (NDS 1.0.1): satu layar fisik,
 * resolusi asli 256x192, filter "None", tanpa layar eksternal / zero-copy / ring buffer.
 * Alur per frame sama dengan aslinya: frameWord -> waitScreen -> fxRender -> eglSwapBuffers.
 */
class SeedlessGlView(context: Context) : SurfaceView(context) {

    private val renderer = DsRenderer()
    private val thread = RenderThread()

    /** Persegi layar bawah (x, y, lebar, tinggi) dalam piksel view; dipakai untuk memetakan sentuhan. */
    @Volatile var bottomScreenRect: FloatArray = floatArrayOf(0f, 0f, 0f, 0f)
        private set

    /** Persegi layar atas (piksel view); dipakai editor susunan kustom sebagai titik awal. */
    @Volatile var topScreenRect: FloatArray = floatArrayOf(0f, 0f, 0f, 0f)
        private set

    /** true bila layar bawah disembunyikan pada susunan kustom (sentuhan diabaikan). */
    @Volatile var bottomHidden = false
        private set

    /** Pratinjau susunan dari editor ([x,y,w,h,hidden] ternormalisasi); null = pakai pengaturan tersimpan. */
    @Volatile private var previewTop: FloatArray? = null
    @Volatile private var previewBot: FloatArray? = null

    @Volatile var onFirstFrame: (() -> Unit)? = null

    // Pengaturan tampilan khusus NDS (dibaca dari SeedlessSettings, bukan Settings emulator lain).
    private val cfg = SeedlessSettings(context)
    @Volatile private var filterName = cfg.filter
    @Volatile private var layoutMode = cfg.layoutMode
    @Volatile private var swapScreens = cfg.swapScreens
    @Volatile private var stretchScreens = cfg.stretch
    @Volatile private var displayDirty = false

    /**
     * Mode gamepad fisik: layar utama memenuhi seluruh view, layar satunya kecil di pojok kanan atas dan SELALU digambar
     * paling akhir (di atas layar utama). Utama = layar sentuh (bawah NDS), atau layar atas NDS bila ditukar.
     */
    @Volatile private var gamepadMode = false

    // Posisi layar kecil mode gamepad (pecahan 0..1, -1 = bawaan pojok kanan atas); digeser pengguna dengan tahan lama lalu seret.
    @Volatile private var pipX = cfg.gamepadPipX
    @Volatile private var pipY = cfg.gamepadPipY
    /**
     * Waktu terakhir layar kecil mode gamepad "diaktifkan" (tukar layar, geser, ganti mode, ubah pengaturan).
     * Dua detik setelahnya layar kecil memudar jadi transparan (masih samar terlihat supaya pemain tahu letaknya).
     */
    @Volatile private var pipActiveAt = SystemClock.uptimeMillis()
    private fun wakePip() { pipActiveAt = SystemClock.uptimeMillis() }

    private var gestureOn = false
    private var pipState = 0            // 0 = bukan geser, 1 = menunggu tahan lama, 2 = sedang menggeser
    private var pipDownX = 0f; private var pipDownY = 0f
    private var pipGrabX = 0f; private var pipGrabY = 0f
    private val pipSlop = ViewConfiguration.get(context).scaledTouchSlop * 2
    private val pipLongPress = Runnable {
        if (pipState == 1) {
            pipState = 2
            releaseTouch()   // lepas stylus yang sempat tertekan; mulai sekarang jari hanya menggeser
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
    }

    /** Persegi layar kecil (piksel view) bila mode gamepad aktif; null bila tidak. Kecil = atas NDS, atau bawah NDS bila ditukar. */
    private fun pipRect(): FloatArray? {
        if (!gamepadMode || previewTop != null || previewBot != null) return null
        val r = if (cfg.swapScreens) bottomScreenRect else topScreenRect
        return if (r[2] > 0f && r[3] > 0f) r else null
    }

    private fun dragPip(left: Float, top: Float) {
        val r = pipRect() ?: return
        val maxX = (width - r[2]).coerceAtLeast(1f)
        val maxY = (height - r[3]).coerceAtLeast(1f)
        pipX = (left / maxX).coerceIn(0f, 1f)
        pipY = (top / maxY).coerceIn(0f, 1f)
        wakePip()
        displayDirty = true
    }

    /** Terapkan posisi layar kecil dari pengaturan (mis. setelah direset lewat menu). */
    private fun reloadPip() { pipX = cfg.gamepadPipX; pipY = cfg.gamepadPipY }

    fun setGamepadMode(on: Boolean) {
        if (gamepadMode == on) return
        gamepadMode = on
        releaseTouch()
        wakePip()
        displayDirty = true
    }

    /** Jumlah frame yang sudah ditampilkan; dipakai penghitung FPS. */
    @Volatile var framesPresented = 0L
        private set

    /** Baca ulang filter dan susunan layar dari pengaturan; diterapkan pada frame berikutnya (tanpa memulai ulang game). */
    fun applyDisplay() {
        reloadPip()
        filterName = cfg.filter
        layoutMode = cfg.layoutMode
        swapScreens = cfg.swapScreens
        stretchScreens = cfg.stretch
        wakePip()
        displayDirty = true
    }

    /**
     * Tukar layar atas/bawah SEKETIKA saat game berjalan (tanpa jeda): balik pengaturan, lalu thread GL menulis ulang
     * geometri pada frame berikutnya. Berlaku di semua susunan (otomatis, atas-bawah, kiri-kanan, kustom).
     * Sentuhan stylus yang sedang aktif dilepas supaya tidak "loncat" ke layar yang baru. Mengembalikan status tukar sekarang.
     */
    fun toggleSwap(): Boolean {
        val v = !cfg.swapScreens
        cfg.swapScreens = v
        releaseTouch()
        applyDisplay()
        return v
    }

    /** Lepas stylus saja (tombol yang sedang ditahan tidak disentuh). */
    fun releaseTouch() { touchActive = false; touchRejected = false; touchPacked = 0; pushInput() }

    /** Tampilkan susunan dari editor secara langsung tanpa menyimpan. Panggil dengan (null, null) untuk mengakhiri pratinjau. */
    fun previewLayout(top: FloatArray?, bot: FloatArray?) {
        previewTop = top; previewBot = bot
        displayDirty = true
    }

    /**
     * Titik awal editor: susunan kustom tersimpan untuk orientasi sekarang, atau (bila belum ada)
     * posisi layar seperti yang sedang terlihat. Mengembalikan pasangan (atas, bawah) = [x,y,w,h,hidden] ternormalisasi.
     */
    fun rectsForEditing(): Pair<FloatArray, FloatArray>? {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return null
        val portrait = h > w
        val st = cfg.customScreen(portrait, true)
        val sb = cfg.customScreen(portrait, false)
        // Pada susunan kustom yang sedang ditukar, layar atas NDS tampil di posisi "bawah" tersimpan dan sebaliknya;
        // editor dimulai dari apa yang terlihat. (Saat disimpan, tanda tukar dimatikan karena sudah tercermin di posisi.)
        if (st != null && sb != null) return if (swapScreens && layoutMode == SeedlessSettings.MODE_CUSTOM) sb to st else st to sb
        val t = topScreenRect; val b = bottomScreenRect
        if (t[2] <= 0f || t[3] <= 0f || b[2] <= 0f || b[3] <= 0f) return null
        return floatArrayOf(t[0] / w, t[1] / h, t[2] / w, t[3] / h, 0f) to
            floatArrayOf(b[0] / w, b[1] / h, b[2] / w, b[3] / h, 0f)
    }

    @Volatile private var touchRejected = false
    @Volatile private var edgeGuard = false

    @Volatile private var padState = 0
    @Volatile private var touchActive = false
    @Volatile private var touchPacked = 0

    private fun pushInput() {
        if (!SeedlessGate.alive) return
        SeedlessCore.input(padState or (if (touchActive) 0x80000000.toInt() else 0), touchPacked, 0)
    }

    /** Bit tombol core: UP0 DOWN1 LEFT2 RIGHT3 A4 B5 X6 Y7 L8 R9 START10 SELECT11. */
    fun setButton(bit: Int, pressed: Boolean) {
        if (bit < 0) return
        padState = if (pressed) padState or (1 shl bit) else padState and (1 shl bit).inv()
        pushInput()
    }

    fun releaseAll() { padState = 0; touchActive = false; touchPacked = 0; pushInput() }

    /** [x],[y] dalam piksel view; sentuhan di luar layar bawah dijepit ke tepinya, ACTION_UP melepas stylus. */
    fun touch(down: Boolean, x: Float, y: Float) {
        if (!down) {
            removeCallbacks(pipLongPress)
            if (pipState == 2) { cfg.gamepadPipX = pipX; cfg.gamepadPipY = pipY }
            pipState = 0; gestureOn = false
            touchActive = false; touchRejected = false; touchPacked = 0; pushInput(); return
        }
        // Mode gamepad: tahan jari di layar kecil lalu seret = pindahkan layar kecil ke mana saja.
        if (!gestureOn) {
            gestureOn = true; pipState = 0
            val pr = pipRect()
            if (pr != null && x >= pr[0] && x <= pr[0] + pr[2] && y >= pr[1] && y <= pr[1] + pr[3]) {
                pipState = 1; pipDownX = x; pipDownY = y; pipGrabX = x - pr[0]; pipGrabY = y - pr[1]
                postDelayed(pipLongPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
        } else if (pipState == 1 && (Math.abs(x - pipDownX) > pipSlop || Math.abs(y - pipDownY) > pipSlop)) {
            pipState = 0; removeCallbacks(pipLongPress)   // jari bergerak sebelum waktunya: ini goresan stylus biasa
        }
        if (pipState == 2) { dragPip(x - pipGrabX, y - pipGrabY); return }
        val r = bottomScreenRect
        if (r[2] <= 0f || r[3] <= 0f || bottomHidden) return
        // Susunan kustom: layar bawah bisa kecil, jadi sentuhan yang BERMULA di luarnya (di luar margin kecil) diabaikan
        // sampai jari diangkat; supaya ketukan di area kosong tidak menekan tepi layar sentuh.
        if (edgeGuard && !touchActive && !touchRejected) {
            val m = 0.08f * minOf(r[2], r[3])
            if (x < r[0] - m || x > r[0] + r[2] + m || y < r[1] - m || y > r[1] + r[3] + m) touchRejected = true
        }
        if (touchRejected) return
        val lx = ((x - r[0]) / r[2]).coerceIn(0f, 1f)
        val ly = ((y - r[1]) / r[3]).coerceIn(0f, 1f)
        val dx = (lx * 255f).toInt().coerceIn(0, 255)
        val dy = (ly * 191f).toInt().coerceIn(0, 191)
        touchActive = true; touchPacked = (dx shl 16) or dy; pushInput()
    }

    init {
        keepScreenOn = true
        holder.setFormat(PixelFormat.RGB_565)
        holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) {}
            override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) =
                thread.onSurfaceReady(h.surface, w, hh)
            override fun surfaceDestroyed(h: SurfaceHolder) = thread.onSurfaceGone()
        })
        thread.start()
    }

    fun onPause() { SeedlessGate.signal(); thread.setPaused(true) }

    /**
     * Lepas thread render dari core sebelum core ditutup: berhenti menggambar dan menunggu sampai thread tidak lagi berada di
     * dalam panggilan core (termasuk waitScreen, yang dibangunkan berulang). Dipanggil dari thread selain render.
     * @return true bila thread render sudah benar-benar diam.
     */
    fun detachCore(timeoutMs: Long): Boolean = thread.detachCore(timeoutMs)
    fun onResume() = thread.setPaused(false)

    override fun onDetachedFromWindow() {
        thread.shutdown()
        super.onDetachedFromWindow()
    }

    private inner class RenderThread : Thread("DsRender") {
        private val lock = Object()
        private var pending: Surface? = null
        private var pendingW = 0
        private var pendingH = 0
        private var surfaceChanged = false
        private var dropWindow = false
        private var exiting = false
        private var paused = false
        /** false = jangan sentuh core lagi (menjelang penutupan). [inDraw] = sedang di dalam panggilan core. */
        private var coreOn = true
        private var inDraw = false

        private val egl = EGLContext.getEGL() as EGL10
        private var dpy: EGLDisplay? = null
        private var cfg: EGLConfig? = null
        private var ctx: EGLContext? = null
        private var win: EGLSurface? = null
        private var winW = 0
        private var winH = 0
        private var started = false
        private var current: Surface? = null

        fun onSurfaceReady(surface: Surface, w: Int, h: Int) = synchronized(lock) {
            pending = surface; pendingW = w; pendingH = h; surfaceChanged = true
            lock.notifyAll()
        }

        fun onSurfaceGone() {
            SeedlessGate.signal()
            synchronized(lock) {
                pending = null
                dropWindow = true
                lock.notifyAll()
                val deadline = System.currentTimeMillis() + 800
                while (dropWindow && System.currentTimeMillis() < deadline) {
                    runCatching { lock.wait(100) }
                }
            }
        }

        fun setPaused(value: Boolean) = synchronized(lock) { paused = value; lock.notifyAll() }

        fun detachCore(timeoutMs: Long): Boolean {
            synchronized(lock) { coreOn = false; lock.notifyAll() }
            val deadline = System.currentTimeMillis() + timeoutMs
            while (true) {
                val idle = synchronized(lock) { !inDraw }
                if (idle) return true
                if (System.currentTimeMillis() >= deadline) return false
                SeedlessGate.signal()   // bangunkan waitScreen bila thread render sedang menunggu frame
                synchronized(lock) { if (inDraw) runCatching { lock.wait(15) } }
            }
        }

        fun shutdown() {
            SeedlessGate.signal()
            synchronized(lock) { exiting = true; lock.notifyAll() }
            runCatching { join(1000) }
        }

        override fun run() {
            while (true) {
                var surface: Surface? = null
                var w = 0
                var h = 0
                var fresh = false
                synchronized(lock) {
                    while (true) {
                        if (dropWindow) { destroyWindow(); dropWindow = false; lock.notifyAll() }
                        if (exiting) { teardown(); return }
                        if (!paused && coreOn && pending != null) {
                            surface = pending; w = pendingW; h = pendingH
                            fresh = surfaceChanged; surfaceChanged = false
                            inDraw = true
                            break
                        }
                        runCatching { lock.wait() }
                    }
                }
                var ok = false
                try {
                    ok = ensureWindow(surface!!, w, h, fresh)
                    if (ok) {
                        val drew = renderer.draw()
                        egl.eglSwapBuffers(dpy, win)
                        if (drew) renderer.afterSwap()
                    }
                } finally {
                    synchronized(lock) { inDraw = false; lock.notifyAll() }
                }
                if (!ok) runCatching { sleep(16) }
            }
        }

        private fun ensureWindow(surface: Surface, w: Int, h: Int, fresh: Boolean): Boolean {
            if (!initEgl()) return false
            if (win != null && (fresh || !(current === surface && surface.isValid))) destroyWindow()
            if (win == null) {
                val s = egl.eglCreateWindowSurface(dpy, cfg, surface, null)
                if (s == null || s == EGL10.EGL_NO_SURFACE) return false
                win = s
                current = surface
                if (!egl.eglMakeCurrent(dpy, s, s, ctx)) { destroyWindow(); return false }
                winW = 0; winH = 0
                if (!started) { renderer.created(); started = true }
            }
            if (w != winW || h != winH) {
                winW = w; winH = h
                renderer.changed(w, h)
            }
            return true
        }

        private fun initEgl(): Boolean {
            if (ctx != null) return true
            val d = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY)
            if (d == null || d == EGL10.EGL_NO_DISPLAY) return false
            if (!egl.eglInitialize(d, IntArray(2))) return false
            val attribs = intArrayOf(
                EGL10.EGL_RED_SIZE, 5, EGL10.EGL_GREEN_SIZE, 6, EGL10.EGL_BLUE_SIZE, 5, EGL10.EGL_ALPHA_SIZE, 0,
                EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL10.EGL_SURFACE_TYPE, EGL10.EGL_WINDOW_BIT,
                EGL10.EGL_NONE,
            )
            val out = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (!egl.eglChooseConfig(d, attribs, out, 1, n) || n[0] == 0) return false
            val c = out[0] ?: return false
            val context = egl.eglCreateContext(d, c, EGL10.EGL_NO_CONTEXT,
                intArrayOf(EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE))
            if (context == null || context == EGL10.EGL_NO_CONTEXT) return false
            dpy = d; cfg = c; ctx = context
            return true
        }

        private fun destroyWindow() {
            val d = dpy ?: return
            win?.let {
                egl.eglMakeCurrent(d, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT)
                runCatching { egl.eglDestroySurface(d, it) }
            }
            win = null
            current = null
        }

        private fun teardown() {
            destroyWindow()
            val d = dpy ?: return
            ctx?.let { runCatching { egl.eglDestroyContext(d, it) } }
            ctx = null
            runCatching { egl.eglTerminate(d) }
            dpy = null
            started = false
        }
    }

    private companion object {
        const val EGL_OPENGL_ES2_BIT = 4
        const val EGL_CONTEXT_CLIENT_VERSION = 0x3098
        const val SRC_W = 256
        const val SRC_H = 192
        const val BG_ATTR = 7
        /** Layar kecil mode gamepad: diam sekian ms -> memudar selama PIP_FADE_MS sampai keburaman PIP_MIN_ALPHA. */
        const val PIP_FADE_DELAY_MS = 2000L
        const val PIP_FADE_MS = 400L
        const val PIP_MIN_ALPHA = 0.15f
    }

    private inner class DsRenderer {
        private val FX_UV_BLOCK = floatArrayOf(
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 1f, 0f, 1f, 1f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
        )
        private var topTex = 0
        private var bottomTex = 0
        private var vbo = 0
        private var viewW = 0
        private var viewH = 0
        private var topPxW = SRC_W; private var topPxH = SRC_H
        private var botPxW = SRC_W; private var botPxH = SRC_H
        private var presentSet = false
        /** Mode gamepad aktif pada geometri terakhir, dan apakah layar atas NDS yang jadi layar kecil (slot 1). */
        private var gpActive = false
        private var gpSmallIsTop = false
        private var loadedFilter = ""

        // ---- pemudaran layar kecil (mode gamepad) ----
        private var pipProg = 0
        private var pipBuf = 0
        private var pipLocTex = -1
        private var pipLocRect = -1
        private var pipLocAlpha = -1

        private fun createPipProgram() {
            pipProg = 0; pipBuf = 0
            try {
                val vs = compileShader(GLES20.GL_VERTEX_SHADER,
                    "attribute vec2 aPos; uniform vec4 uRect; varying vec2 vUv;\n" +
                    "void main(){ vec2 p = mix(uRect.xy, uRect.zw, aPos);\n" +
                    "vUv = vec2(p.x*0.5+0.5, 0.5-p.y*0.5); gl_Position = vec4(p,0.0,1.0); }")
                val fs = compileShader(GLES20.GL_FRAGMENT_SHADER,
                    "precision mediump float; uniform sampler2D uTex; uniform float uAlpha; varying vec2 vUv;\n" +
                    "void main(){ gl_FragColor = vec4(texture2D(uTex, vUv).rgb, uAlpha); }")
                if (vs == 0 || fs == 0) return
                val prog = GLES20.glCreateProgram()
                GLES20.glAttachShader(prog, vs)
                GLES20.glAttachShader(prog, fs)
                GLES20.glBindAttribLocation(prog, BG_ATTR, "aPos")
                GLES20.glLinkProgram(prog)
                val ok = IntArray(1)
                GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
                if (ok[0] == 0) { GLES20.glDeleteProgram(prog); return }
                pipLocTex = GLES20.glGetUniformLocation(prog, "uTex")
                pipLocRect = GLES20.glGetUniformLocation(prog, "uRect")
                pipLocAlpha = GLES20.glGetUniformLocation(prog, "uAlpha")
                val b = IntArray(1)
                GLES20.glGenBuffers(1, b, 0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, b[0])
                val quad = floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f)
                val bb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder())
                bb.asFloatBuffer().put(quad).flip()
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quad.size * 4, bb, GLES20.GL_STATIC_DRAW)
                pipProg = prog; pipBuf = b[0]
            } catch (_: Throwable) { pipProg = 0; pipBuf = 0 }
        }

        /** Keburaman layar kecil: 1 = utuh, turun ke PIP_MIN_ALPHA setelah diam PIP_FADE_DELAY_MS. */
        private fun pipOpacity(): Float {
            val idle = SystemClock.uptimeMillis() - pipActiveAt - PIP_FADE_DELAY_MS
            if (idle <= 0L) return 1f
            val t = (idle.toFloat() / PIP_FADE_MS).coerceAtMost(1f)
            return 1f - t * (1f - PIP_MIN_ALPHA)
        }

        /**
         * Buat layar kecil tembus pandang. Layar besar sudah tergambar utuh di bawahnya (lewat satu panggilan fxRender,
         * supaya halaman piksel kedua layar tetap sama), lalu bagian layar besar tepat di bawah layar kecil digambar ulang
         * di atasnya dengan keburaman (1 - opasitas): hasilnya = kecil*opasitas + besar*(1-opasitas), apa pun filternya.
         */
        private fun drawPipFade(opacity: Float, bigTexture: Int, small: FloatArray) {
            if (pipProg == 0 || viewW <= 0 || viewH <= 0 || small[2] <= 0f || small[3] <= 0f) return
            val prevProg = IntArray(1)
            GLES20.glGetIntegerv(GLES20.GL_CURRENT_PROGRAM, prevProg, 0)
            val x0 = small[0] / viewW * 2f - 1f
            val x1 = (small[0] + small[2]) / viewW * 2f - 1f
            val yt = 1f - small[1] / viewH * 2f
            val yb = 1f - (small[1] + small[3]) / viewH * 2f
            GLES20.glUseProgram(pipProg)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bigTexture)
            GLES20.glUniform1i(pipLocTex, 0)
            GLES20.glUniform4f(pipLocRect, x0, yb, x1, yt)
            GLES20.glUniform1f(pipLocAlpha, 1f - opacity)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, pipBuf)
            GLES20.glEnableVertexAttribArray(BG_ATTR)
            GLES20.glVertexAttribPointer(BG_ATTR, 2, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(BG_ATTR)
            GLES20.glDisable(GLES20.GL_BLEND)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            GLES20.glUseProgram(prevProg[0])
        }

        /** Muat shader .dfx; bila file tidak ada/gagal, jatuh kembali ke None supaya layar tidak hitam. */
        private fun loadFilter(name: String) {
            var n = name
            var r = SeedlessCore.fxLoad(PathCache.SYS_PREFIX + "shaders/$n.dfx", 0, 2208)
            if (r < 0 && n != SeedlessSettings.SAFE_FILTER) {
                n = SeedlessSettings.SAFE_FILTER
                r = SeedlessCore.fxLoad(PathCache.SYS_PREFIX + "shaders/$n.dfx", 0, 2208)
            }
            loadedFilter = n
            android.util.Log.i("SeedlessGl", "filter $n -> hasil muat $r")
            SeedlessCore.fxSetup(SRC_W, SRC_H, 0, 0, viewW, viewH)
        }

        // ---- latar belakang lanskap (gambar di belakang layar NDS, di area hitam sekitar layar/kontrol) ----
        private var bgTex = 0            // lanskap
        private var bgTexP = 0           // potret
        private var bgProg = 0
        private var bgBuf = 0
        private var bgLocTex = -1
        private var bgLocScale = -1
        private var bgAspect = 16f / 9f
        private var bgAspectP = 9f / 16f

        /** Unggah satu gambar latar ke tekstur GL; hasil (id tekstur, lebar/tinggi) atau null bila gagal. */
        private fun loadBgTexture(resId: Int): Pair<Int, Float>? {
            val o = BitmapFactory.Options().apply { inScaled = false }
            val bmp = BitmapFactory.decodeResource(context.resources, resId, o) ?: return null
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            val a = bmp.width.toFloat() / bmp.height
            bmp.recycle()
            return Pair(t[0], a)
        }

        private fun compileShader(type: Int, src: String): Int {
            val sh = GLES20.glCreateShader(type)
            GLES20.glShaderSource(sh, src)
            GLES20.glCompileShader(sh)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) { GLES20.glDeleteShader(sh); return 0 }
            return sh
        }

        /** Muat gambar latar + program kecil sendiri. Gagal apa pun = latar dilewati (layar tetap hitam seperti semula). */
        private fun createBackground() {
            bgTex = 0; bgTexP = 0; bgProg = 0; bgBuf = 0
            try {
                val land = loadBgTexture(R.drawable.bg_nds_landscape)
                val port = loadBgTexture(R.drawable.bg_nds_portrait)
                if (land == null && port == null) return
                land?.let { bgTex = it.first; bgAspect = it.second }
                port?.let { bgTexP = it.first; bgAspectP = it.second }

                val vs = compileShader(GLES20.GL_VERTEX_SHADER,
                    "attribute vec2 aPos; uniform vec2 uScale; varying vec2 vUv;\n" +
                    "void main(){ vec2 uv = vec2(aPos.x*0.5+0.5, 0.5-aPos.y*0.5);\n" +
                    "vUv = (uv-0.5)*uScale+0.5; gl_Position = vec4(aPos,0.0,1.0); }")
                val fs = compileShader(GLES20.GL_FRAGMENT_SHADER,
                    "precision mediump float; uniform sampler2D uTex; varying vec2 vUv;\n" +
                    "void main(){ gl_FragColor = vec4(texture2D(uTex, vUv).rgb, 1.0); }")
                if (vs == 0 || fs == 0) return
                val prog = GLES20.glCreateProgram()
                GLES20.glAttachShader(prog, vs)
                GLES20.glAttachShader(prog, fs)
                // Indeks atribut tinggi supaya tidak bentrok dengan keadaan atribut yang dipakai core native.
                GLES20.glBindAttribLocation(prog, BG_ATTR, "aPos")
                GLES20.glLinkProgram(prog)
                val ok = IntArray(1)
                GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
                if (ok[0] == 0) { GLES20.glDeleteProgram(prog); return }
                bgLocTex = GLES20.glGetUniformLocation(prog, "uTex")
                bgLocScale = GLES20.glGetUniformLocation(prog, "uScale")

                val b = IntArray(1)
                GLES20.glGenBuffers(1, b, 0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, b[0])
                val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
                val bb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder())
                bb.asFloatBuffer().put(quad).flip()
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quad.size * 4, bb, GLES20.GL_STATIC_DRAW)
                bgProg = prog; bgBuf = b[0]
            } catch (_: Throwable) {
                bgTex = 0; bgTexP = 0; bgProg = 0; bgBuf = 0
            }
        }

        /** Gambar latar menutupi seluruh view (potong tepi, tanpa gepeng); gambar lanskap atau potret sesuai orientasi. */
        private fun drawBackground() {
            if (bgProg == 0 || viewH <= 0 || viewW <= 0) return
            val landscape = viewW > viewH
            val tex = if (landscape) bgTex else bgTexP
            val aspect = if (landscape) bgAspect else bgAspectP
            if (tex == 0) return
            val prevProg = IntArray(1)
            GLES20.glGetIntegerv(GLES20.GL_CURRENT_PROGRAM, prevProg, 0)
            val va = viewW.toFloat() / viewH
            val sx: Float; val sy: Float
            if (va > aspect) { sx = 1f; sy = aspect / va } else { sx = va / aspect; sy = 1f }
            GLES20.glUseProgram(bgProg)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            GLES20.glUniform1i(bgLocTex, 0)
            GLES20.glUniform2f(bgLocScale, sx, sy)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bgBuf)
            GLES20.glEnableVertexAttribArray(BG_ATTR)
            GLES20.glVertexAttribPointer(BG_ATTR, 2, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(BG_ATTR)
            // Kembalikan keadaan yang diandalkan penggambar layar.
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            GLES20.glUseProgram(prevProg[0])
        }

        fun created() {
            presentSet = false
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            createBackground()
            createPipProgram()
            val tex = IntArray(2)
            GLES20.glGenTextures(2, tex, 0)
            topTex = tex[0]; bottomTex = tex[1]
            createScreenTexture(topTex)
            createScreenTexture(bottomTex)
            SeedlessCore.clearScreens(topTex, bottomTex)

            val buf = IntArray(1)
            GLES20.glGenBuffers(1, buf, 0)
            vbo = buf[0]
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, 4416, null, GLES20.GL_DYNAMIC_DRAW)

            val fullQuad = floatArrayOf(-1f, 1f, -1f, -1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f)
            writeVbo(96, fullQuad)
            writeVbo(144, fullQuad)
            writeVbo(2208, FX_UV_BLOCK)

            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_BLEND)
        }

        private fun createScreenTexture(id: Int) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, SRC_W, SRC_H, 0,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR.toFloat())
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR.toFloat())
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        fun changed(width: Int, height: Int) {
            viewW = width; viewH = height
            GLES20.glViewport(0, 0, width, height)
            GLES20.glClearColor(0f, 0f, 0f, 1f)

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            writeScreenGeometry(width, height)

            loadFilter(filterName)
            SeedlessCore.applyConfig(SeedlessSupport.configBits(cfg))
        }

        private fun fit(maxW: Float, maxH: Float): Pair<Float, Float> {
            if (stretchScreens) return Pair(maxW, maxH)
            val a = SRC_W.toFloat() / SRC_H
            return if (maxW / maxH > a) Pair(maxH * a, maxH) else Pair(maxW, maxW / a)
        }

        private fun quadNdc(w: Int, h: Int, r: FloatArray): FloatArray {
            fun ndx(px: Float) = px / w * 2f - 1f
            fun ndy(px: Float) = 1f - px / h * 2f
            val x0 = ndx(r[0]); val x1 = ndx(r[0] + r[2]); val yt = ndy(r[1]); val yb = ndy(r[1] + r[3])
            return floatArrayOf(x0, yt, x0, yb, x1, yb, x0, yt, x1, yb, x1, yt)
        }

        /** Susunan bawaan (mode 0/1/2) sebagai persegi piksel: (layar atas NDS, layar bawah NDS). */
        /** Susunan bawaan lanskap (mode otomatis, tanpa regang) aktif? Lihat [landscapeDefaultRects]. */
        private fun useLandscapeDefault(w: Int, h: Int) = layoutMode == 0 && w > h && !stretchScreens

        /**
         * Susunan bawaan lanskap (diukur dari screenshot pengguna 2400x1080): layar sentuh (bawah NDS) besar 4:3
         * penuh tinggi di tengah, layar atas NDS kecil di sisi kanannya (menempel ke tepi kanan, tinggi 0,413 dan
         * mulai 0,201 dari tinggi view). Bila ditukar, layar atas yang besar di tengah dan layar bawah yang kecil.
         */
        private fun landscapeDefaultRects(w: Int, h: Int): Pair<FloatArray, FloatArray> {
            val a = SRC_W.toFloat() / SRC_H
            val bh = h.toFloat()
            val bw = minOf(w.toFloat(), bh * a)
            val big = floatArrayOf((w - bw) / 2f, 0f, bw, bh)
            val sx = big[0] + bw + 0.0092f * w
            val sh = 0.413f * h
            val sw = minOf(w - sx, sh * a).coerceAtLeast(1f)
            val small = floatArrayOf(sx, 0.2009f * h, sw, sh)
            return if (swapScreens) big to small else small to big
        }

        /** Mode gamepad: (layar utama penuh, layar kecil di pojok kanan atas). Utama = bawah NDS, atau atas NDS bila ditukar. */
        private fun gamepadRects(w: Int, h: Int): Pair<FloatArray, FloatArray> {
            val a = SRC_W.toFloat() / SRC_H
            val big = floatArrayOf(0f, 0f, w.toFloat(), h.toFloat())
            val sw = minOf(0.30f * h * a, 0.32f * w).coerceAtLeast(1f)
            val sh = sw / a
            val margin = 0.01f * minOf(w, h)
            val px = pipX; val py = pipY
            val x = if (px < 0f) w - sw - margin else px * (w - sw).coerceAtLeast(0f)
            val y = if (py < 0f) margin else py * (h - sh).coerceAtLeast(0f)
            return big to floatArrayOf(x, y, sw, sh)
        }

        private fun presetRects(w: Int, h: Int): Pair<FloatArray, FloatArray> {
            if (useLandscapeDefault(w, h)) return landscapeDefaultRects(w, h)
            // Mode otomatis: potret = atas-bawah, lanskap = kiri-kanan. Mode 1/2 memaksa salah satunya.
            val vertical = when (layoutMode) { 1 -> true; 2 -> false; else -> h > w }
            val first: FloatArray    // slot kiri / atas
            val second: FloatArray   // slot kanan / bawah
            if (vertical) {
                val (sw, sh) = fit(w.toFloat(), h / 2f)
                val x = (w - sw) / 2f
                // potret: menempel di atas layar (kontrol di bawahnya); lanskap: di tengah
                val y = if (h > w) 0f else (h - 2f * sh) / 2f
                first = floatArrayOf(x, y, sw, sh)
                second = floatArrayOf(x, y + sh, sw, sh)
            } else {
                val halfW = w / 2f
                val (sw, sh) = fit(halfW, h.toFloat())
                val y = (h - sh) / 2f
                first = floatArrayOf((halfW - sw) / 2f, y, sw, sh)
                second = floatArrayOf(halfW + (halfW - sw) / 2f, y, sw, sh)
            }
            // Tukar layar: layar atas NDS digambar di slot kedua, layar bawah (sentuh) di slot pertama.
            return if (swapScreens) second to first else first to second
        }

        private fun writeScreenGeometry(w: Int, h: Int) {
            var (top, bot) = presetRects(w, h)
            var topHide = false
            var botHide = false
            val gp = gamepadMode && previewTop == null && previewBot == null
            if (gp) {
                val (big, small) = gamepadRects(w, h)
                // Tukar layar: layar atas NDS jadi utama (penuh), layar bawah jadi kecil. Tanpa tukar: kebalikannya.
                if (swapScreens) { top = big; bot = small } else { top = small; bot = big }
            }
            gpActive = gp
            // Susunan kustom: dari pratinjau editor bila sedang mengedit, kalau tidak dari pengaturan tersimpan
            // untuk orientasi ini. Bila belum pernah diatur, tetap memakai susunan bawaan di atas.
            val pt = previewTop; val pb = previewBot
            if (!gp && ((pt != null && pb != null) || layoutMode == SeedlessSettings.MODE_CUSTOM)) {
                val portrait = h > w
                val ct = pt ?: cfg.customScreen(portrait, true)
                val cb = pb ?: cfg.customScreen(portrait, false)
                if (ct != null && cb != null) {
                    // Tukar layar juga berlaku di susunan kustom (kecuali saat pratinjau editor, yang sudah apa adanya).
                    val swapNow = swapScreens && pt == null
                    val rt = if (swapNow) cb else ct
                    val rb = if (swapNow) ct else cb
                    top = floatArrayOf(rt[0] * w, rt[1] * h, maxOf(rt[2] * w, 1f), maxOf(rt[3] * h, 1f))
                    bot = floatArrayOf(rb[0] * w, rb[1] * h, maxOf(rb[2] * w, 1f), maxOf(rb[3] * h, 1f))
                    topHide = rt[4] > 0.5f
                    botHide = rb[4] > 0.5f
                    if (topHide && botHide) topHide = false   // jangan sampai dua-duanya hilang (layar hitam)
                }
            }
            // Layar tersembunyi digambar jauh di luar view (ukuran piksel tetap, jadi shader aman).
            fun hidden(r: FloatArray) = floatArrayOf(-4f * w - r[2], r[1], r[2], r[3])
            val geo = FloatArray(24)
            // Urutan gambar = urutan slot (slot 0 dulu, slot 1 menimpa). Mode gamepad: slot 0 = layar utama, slot 1 = layar kecil,
            // jadi layar kecil selalu di atas layar utama, apa pun layar NDS yang sedang jadi utama.
            val smallIsTop = gp && !swapScreens
            gpSmallIsTop = smallIsTop
            val first = if (smallIsTop) bot else top
            val second = if (smallIsTop) top else bot
            val firstHide = if (smallIsTop) botHide else topHide
            val secondHide = if (smallIsTop) topHide else botHide
            System.arraycopy(quadNdc(w, h, if (firstHide) hidden(first) else first), 0, geo, 0, 12)
            System.arraycopy(quadNdc(w, h, if (secondHide) hidden(second) else second), 0, geo, 12, 12)
            topPxW = top[2].toInt().coerceAtLeast(1); topPxH = top[3].toInt().coerceAtLeast(1)
            botPxW = bot[2].toInt().coerceAtLeast(1); botPxH = bot[3].toInt().coerceAtLeast(1)
            topScreenRect = top
            bottomScreenRect = bot
            bottomHidden = botHide
            // Sentuhan yang bermula jauh di luar layar sentuh (area tombol) diabaikan pada susunan kustom dan susunan bawaan lanskap
            // Mode gamepad: penjaga tepi hanya perlu saat layar sentuh sedang kecil (bawah NDS = layar kecil bila ditukar).
            edgeGuard = if (gp) swapScreens else (layoutMode == SeedlessSettings.MODE_CUSTOM || useLandscapeDefault(w, h))
            writeVbo(0, geo)
            writeVbo(2208, FX_UV_BLOCK)
        }

        /** Terapkan perubahan filter/susunan layar dari menu pengaturan (dipanggil di thread GL). */
        private fun applyDisplayChanges() {
            if (!displayDirty) return
            displayDirty = false
            if (viewW <= 0 || viewH <= 0) return
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            writeScreenGeometry(viewW, viewH)
            if (filterName != loadedFilter) loadFilter(filterName)
        }

        private fun writeVbo(offsetBytes: Int, data: FloatArray) {
            val b = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
            b.asFloatBuffer().put(data).flip()
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, offsetBytes, data.size * 4, b)
        }

        private fun setPresentMode() {
            if (presentSet) return
            presentSet = runCatching { SeedlessBridge.presentMode(3) }.getOrDefault(false)
        }

        fun draw(): Boolean {
            setPresentMode()
            applyDisplayChanges()
            val i7 = SeedlessCore.frameWord() and 0xFFFF
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            if (i7 != 0) return false
            drawBackground()
            SeedlessCore.waitScreen()
            GLES20.glDisable(GLES20.GL_BLEND)
            if (gpActive && gpSmallIsTop) {
                // slot 0 = layar bawah NDS (utama), slot 1 = layar atas NDS (kecil, digambar terakhir).
                // Argumen terakhir (flag) memilih halaman piksel mana yang diunggah ke tekstur pertama:
                // false = layar 0 (atas NDS), true = layar 1 (bawah NDS). Tekstur pertama di sini adalah bottomTex,
                // jadi flag HARUS true; kalau false, bottomTex berisi layar atas dan tukar layar tidak terlihat berubah
                // (layar besar selalu menampilkan layar 0 di kedua keadaan tukar).
                SeedlessCore.fxRender(bottomTex, topTex, 0, 6, 18, botPxW, botPxH, topPxW, topPxH, true)
            } else {
                SeedlessCore.fxRender(topTex, bottomTex, 0, 6, 18, topPxW, topPxH, botPxW, botPxH, false)
            }
            if (gpActive) {
                val op = pipOpacity()
                if (op < 1f) {
                    // layar besar = bawah NDS bila atas jadi kecil, selain itu atas NDS; layar kecil = yang satunya
                    if (gpSmallIsTop) drawPipFade(op, bottomTex, topScreenRect)
                    else drawPipFade(op, topTex, bottomScreenRect)
                }
            }
            return true
        }

        fun afterSwap() {
            framesPresented++
            onFirstFrame?.let { cb -> onFirstFrame = null; post { cb() } }
        }
    }
}
