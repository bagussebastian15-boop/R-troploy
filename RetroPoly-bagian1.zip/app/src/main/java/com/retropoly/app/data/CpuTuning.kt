package com.retropoly.app.data

import com.swordfish.libretrodroid.Variable

/**
 * Kecepatan CPU emulasi untuk SNES dan Genesis (mengurangi slowdown/lag bawaan game yang berat).
 * 100% = perilaku asli (tidak ada yang diubah); bawaan aplikasi 300%. Di atas 100% lebih lancar tapi lebih berat bagi HP,
 * dan sebagian kecil game bisa bermasalah.
 *
 * SNES (snes9x): `snes9x_overclock_cycles` (disabled/compatible/max) untuk CPU utama, dan
 *   `snes9x_overclock_superfx` (persen) untuk chip SuperFX (Star Fox, Yoshi's Island, dst.).
 * Genesis (genesis_plus_gx): `genesis_plus_gx_overclock` (persen) untuk CPU 68000.
 * GBA: core mGBA tidak punya opsi kecepatan CPU, jadi tidak ada pengaturan untuk GBA.
 */
object CpuTuning {
    const val DEFAULT = 100
    /** Bawaan kecepatan CPU SNES dan Genesis: 300%. */
    const val DEFAULT_SNES_GENESIS = 300

    val SNES_CHOICES = listOf(100, 150, 200, 300, 400)
    val GENESIS_CHOICES = listOf(100, 125, 150, 175, 200, 250, 300, 400)

    private val SNES_SUPERFX = listOf(100, 150, 200, 250, 300, 350, 400)

    fun snesLabel(p: Int) = when {
        p <= 100 -> "100% (asli)"
        p < 200 -> "$p% (kompatibel)"
        else -> "$p% (maksimal)"
    }

    /** Variabel core untuk satu konsol; selalu dikirim (termasuk 100%) supaya kembali ke asli bila diturunkan. */
    fun variables(console: Console, snesPercent: Int, genesisPercent: Int): List<Variable> = when (console) {
        Console.SNES -> {
            val mode = when { snesPercent >= 200 -> "max"; snesPercent > 100 -> "compatible"; else -> "disabled" }
            val fx = SNES_SUPERFX.minByOrNull { Math.abs(it - snesPercent) } ?: 100
            listOf(
                Variable("snes9x_overclock_cycles", mode),
                Variable("snes9x_overclock_superfx", "$fx%")
            )
        }
        Console.GENESIS -> {
            val g = GENESIS_CHOICES.minByOrNull { Math.abs(it - genesisPercent) } ?: 100
            listOf(Variable("genesis_plus_gx_overclock", "$g%"))
        }
        else -> emptyList()
    }
}
