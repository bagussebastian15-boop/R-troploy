package com.retropoly.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Latar "gambar hidup": rumput bergoyang, air beriak, gelembung naik, serbuk cahaya melayang,
 * matahari berdenyut, kilau menyapu air, dan zoom pelan. Semua digambar langsung di Canvas
 * dari satu gambar (tanpa video), jadi ringan dan berhenti otomatis saat layar tidak terlihat.
 */
class NatureBackgroundView(context: Context, private val resId: Int) : View(context) {

    private val bmp: Bitmap = BitmapFactory.decodeResource(
        resources, resId, BitmapFactory.Options().apply { inScaled = false }
    )
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = screen }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = screen }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    // Mesh: seluruh gambar dibagi petak; titik petak digeser gelombang sin untuk efek angin / air.
    private val mw = 48
    private val mh = 54
    private val orig = FloatArray((mw + 1) * (mh + 1) * 2)
    private val warped = FloatArray(orig.size)

    private val rnd = Random(7)
    private class Bubble(var x: Float, var y: Float, var r: Float, var s: Float, var p: Float, var w: Float)
    private class Pollen(var x: Float, var y: Float, var r: Float, var vx: Float, var vy: Float, var p: Float)
    private val bubbles = ArrayList<Bubble>()
    private val pollen = ArrayList<Pollen>()

    // Letak garis air & matahari pada gambar (pecahan 0..1)
    private val waterY = 0.61f

    private var running = false
    private var t0 = SystemClock.uptimeMillis()
    private var last = t0
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // geometri hasil hitung per ukuran layar
    private var dl = 0f; private var dt = 0f; private var dw = 0f; private var dh = 0f

    fun start() {
        if (running) return
        running = true
        last = SystemClock.uptimeMillis()
        Choreographer.getInstance().postFrameCallback(frame)
    }

    fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (visibility == VISIBLE) start() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) start() else stop()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bubbles.clear(); pollen.clear()
        val d = resources.displayMetrics.density
        repeat(24) { bubbles += newBubble(d, true) }
        repeat(44) { pollen += newPollen(d, true) }
    }

    private fun waterLine() = if (dh > 0f) dt + dh * waterY else height * 0.63f

    private fun newBubble(d: Float, init: Boolean) = Bubble(
        x = rnd.nextFloat() * width,
        y = if (init) waterLine() + rnd.nextFloat() * max(1f, height - waterLine()) else height + 20f * d,
        r = (2f + rnd.nextFloat() * 7f) * d, s = (14f + rnd.nextFloat() * 38f) * d,
        p = rnd.nextFloat() * 6.28f, w = (6f + rnd.nextFloat() * 22f) * d
    )

    private fun newPollen(d: Float, init: Boolean): Pollen {
        val top = waterLine()
        return Pollen(
            x = rnd.nextFloat() * width,
            y = if (init) rnd.nextFloat() * top else top * (0.6f + rnd.nextFloat() * 0.4f),
            r = (0.7f + rnd.nextFloat() * 1.6f) * d, vx = (5f + rnd.nextFloat() * 18f) * d,
            vy = -(3f + rnd.nextFloat() * 14f) * d, p = rnd.nextFloat() * 6.28f
        )
    }

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t)
    }

    override fun onDraw(canvas: Canvas) {
        val vw = width.toFloat(); val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val now = SystemClock.uptimeMillis()
        val dtSec = ((now - last) / 1000f).coerceIn(0f, 0.05f); last = now
        val t = (now - t0) / 1000f
        val d = resources.displayMetrics.density

        // zoom pelan bolak-balik (Ken Burns); skala min 1.06 supaya tepi tidak terbuka saat mesh bergeser
        val z = 1.06f + 0.05f * (0.5f - 0.5f * kotlin.math.cos(t * 2f * PI.toFloat() / 40f))
        val cover = max(vw / bmp.width, vh / bmp.height) * z
        dw = bmp.width * cover; dh = bmp.height * cover
        val panX = sin(t * 2f * PI.toFloat() / 53f) * vw * 0.012f
        dl = (vw - dw) / 2f + panX
        // sejajarkan agar garis air ± di bagian bawah-tengah layar
        dt = (vh - dh) * 0.62f

        // ---- mesh bergelombang
        val sx = dw / mw; val sy = dh / mh
        var k = 0
        for (j in 0..mh) {
            val fy = j.toFloat() / mh
            for (i in 0..mw) {
                val fx = i.toFloat() / mw
                var ox = 0f; var oy = 0f

                // rumput pendek: goyang makin besar menjauhi garis air, lalu hilang di langit
                val grassW = smooth(waterY, waterY - 0.10f, fy) * (1f - smooth(0.42f, 0.30f, fy))
                // bilah tinggi di kanan: goyang lebih halus sampai ke ujung atas
                val tallW = smooth(0.58f, 0.68f, fx) * smooth(waterY, waterY - 0.12f, fy) * 0.8f
                val w = max(grassW, tallW)
                if (w > 0f) {
                    ox += w * dw * 0.0085f * (sin(t * 1.5f + fx * 9f + fy * 3f) + 0.5f * sin(t * 2.7f + fx * 21f))
                }

                // air: riak dua arah, hilang di garis air agar tepinya tetap tegas
                val waterW = smooth(waterY - 0.012f, waterY + 0.05f, fy)
                if (waterW > 0f) {
                    ox += waterW * dw * 0.0045f * sin(t * 1.8f + fy * 28f + fx * 6f)
                    oy += waterW * dh * 0.0050f * sin(t * 1.4f + fx * 24f + fy * 7f)
                }
                // garis air sendiri bergelombang tipis
                val line = (1f - kotlin.math.abs(fy - waterY) / 0.03f).coerceIn(0f, 1f)
                oy += line * dh * 0.0035f * sin(t * 2.2f + fx * 30f)

                orig[k] = dl + i * sx + ox; orig[k + 1] = dt + j * sy + oy
                k += 2
            }
        }
        canvas.drawBitmapMesh(bmp, mw, mh, orig, 0, null, 0, bitmapPaint)

        // ---- matahari berdenyut
        val sunX = dl + dw * 0.60f; val sunY = dt + dh * 0.0f
        val sr = dw * 0.20f * (1f + 0.10f * sin(t * 1.6f))
        glowPaint.shader = RadialGradient(
            sunX, sunY, sr,
            intArrayOf(0xCCFFFFF0.toInt(), 0x44FFFFDC, 0x00FFFFDC), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        glowPaint.alpha = (200 + 55 * sin(t * 1.6f)).toInt().coerceIn(0, 255)
        canvas.drawCircle(sunX, sunY, sr, glowPaint)

        // ---- kilau menyapu permukaan air
        val wl = waterLine()
        val cycle = (t % 7f) / 7f
        val bandW = vw * 0.30f
        val bx = -bandW + (vw + bandW * 2f) * cycle
        shinePaint.shader = LinearGradient(
            bx, 0f, bx + bandW, 0f,
            intArrayOf(0x00FFFFFF, 0x59FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, wl, vw, vh, shinePaint)

        // ---- serbuk cahaya di udara
        for (p in pollen) {
            p.x += (p.vx + sin(t + p.p) * 6f * d) * dtSec; p.y += p.vy * dtSec
            if (p.x > vw + 6f || p.y < -6f) {
                val n = newPollen(d, false); p.x = -4f + rnd.nextFloat() * vw * 0.5f; p.y = n.y
                p.r = n.r; p.vx = n.vx; p.vy = n.vy; p.p = n.p
            }
            val a = (0.35f + 0.35f * sin(t * 2f + p.p)).coerceIn(0f, 1f)
            dot.color = 0xFFFFF2B8.toInt(); dot.alpha = (a * 255).toInt()
            canvas.drawCircle(p.x, p.y, p.r, dot)
            dot.alpha = (a * 70).toInt()
            canvas.drawCircle(p.x, p.y, p.r * 3.2f, dot)
        }

        // ---- gelembung naik di bawah air
        ring.strokeWidth = 1.2f * d
        for (b in bubbles) {
            b.y -= b.s * dtSec; b.x += sin(t * 1.5f + b.p) * b.w * dtSec
            if (b.y < wl + b.r) {
                val n = newBubble(d, false); b.x = n.x; b.y = n.y; b.r = n.r; b.s = n.s; b.p = n.p; b.w = n.w
            }
            dot.color = 0xFFC8F0FF.toInt(); dot.alpha = 34
            canvas.drawCircle(b.x, b.y, b.r, dot)
            ring.color = 0xFFFFFFFF.toInt(); ring.alpha = 140
            canvas.drawCircle(b.x, b.y, b.r, ring)
            dot.color = 0xFFFFFFFF.toInt(); dot.alpha = 205
            canvas.drawCircle(b.x - b.r * 0.35f, b.y - b.r * 0.35f, b.r * 0.22f, dot)
        }
    }
}
