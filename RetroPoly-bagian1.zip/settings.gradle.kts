pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // Google Maven hanya ditanya untuk grup milik Google/AndroidX. Dulu SEMUA dependensi (mis. junrar) ditanyakan
        // ke dl.google.com dulu, sehingga "Read timed out" di sana menggagalkan build walau junrar ada di Maven Central.
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        maven("https://jitpack.io") {
            content { includeGroup("com.github.Swordfish90") }
        }
    }
}
rootProject.name = "EmulatorAllInOne"
include(":app")
// LibretroDroid dibangun dari sumber (dengan patch netplay rollback). Siapkan dengan: bash scripts/setup_libretrodroid_netplay.sh
include(":libretrodroid")
project(":libretrodroid").projectDir = file("libretrodroid-src/libretrodroid")

// M64Plus FZ (Mupen64Plus AE, GPLv3) tertanam di folder m64plus/. Modul native-nya dibangun dengan ndk-build (arm64-v8a).
// Modul ":app" milik M64Plus FZ dijadikan library dengan nama ":m64plus-app" (":app" sudah dipakai aplikasi ini).
for (m in listOf("ae-bridge", "miniupnp-bridge", "mupen64plus-audio-android", "mupen64plus-core", "mupen64plus-input-android",
    "mupen64plus-input-raphnet", "mupen64plus-rsp-cxd4", "mupen64plus-rsp-hle", "mupen64plus-rsp-parallel",
    "mupen64plus-video-angrylion-plus", "mupen64plus-video-glide64mk2", "mupen64plus-video-gliden64",
    "mupen64plus-video-gln64", "mupen64plus-video-parallel", "mupen64plus-video-rice")) {
    include(":$m")
    project(":$m").projectDir = file("m64plus/$m")
}
include(":m64plus-app")
project(":m64plus-app").projectDir = file("m64plus/app")
